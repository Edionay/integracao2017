$(document).ready(function () {
  $(".button-collapse").sideNav();
  $('.modal').modal();
  $(".button-collapse").sideNav();
  $('.scrollspy').scrollSpy(
    {scrollOffset: 50}
  );
});
